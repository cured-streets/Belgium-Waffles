# Asset Manifest

Approval states: PLANNED, PROMPT READY, GENERATING, CANDIDATE, REVISION NEEDED, APPROVED, IN EDIT, FINAL, REJECTED.

| Asset ID | File Path | Type | Shot ID | Status | Source / Generator | Rights Notes | Notes |
|---|---|---|---|---|---|---|---|
| AUD001 | `assets/audio/belgium-waffles-and-babybatter.mp3` | Audio master | Project-wide | CANDIDATE | Uploaded to GitHub by user | Rights/ownership TODO | MP3, 48 kHz stereo, parsed duration approx. 2:12.38 |
| DOC001 | `docs/LYRICS.md` | Lyrics | Project-wide | CANDIDATE | Uploaded to GitHub by user | Rights/ownership TODO | Raw lyric sheet moved from repository root |
| DOC002 | `docs/LYRICS_AND_TIMECODES.md` | Timing document | Project-wide | CANDIDATE | Arena.ai agent + CapCut auto-lyrics | N/A | CapCut rough sync; useful for scene changes, not final on-screen captions |
| REF001 | `assets/style-references/prehistory-waffle-eatery-reference.jpg` | Style/concept reference | Project-wide | CANDIDATE | Uploaded to GitHub by user | Copyright/trademark clearance TODO; use only as broad inspiration | Retro prehistoric cartoon waffle/eatery composition reference |
| REF002 | `assets/style-references/prehistory-couple-reference.jpg` | Style/concept reference | Project-wide | CANDIDATE | Uploaded to GitHub by user | Copyright/trademark clearance TODO; use only as broad inspiration | Retro prehistoric couple/family-sitcom reference |
| REF003 | `assets/style-references/retro-future-family-reference.jpg` | Style/concept reference | Project-wide | CANDIDATE | Uploaded to GitHub by user | Copyright/trademark clearance TODO; use only as broad inspiration | Retro-futurist cartoon family/home reference |
| CHAR001 | `generations/stills/candidates/CHAR_singer-reference_v001.png` | Character reference candidate | Singer | REJECTED | Arena.ai image generation | Original generated candidate | Good adult country vibe, but rejected due to unwanted readable sign and severe giant boot/leg artifacts |
| CHAR003 | `generations/stills/candidates/CHAR_singer-reference_v002.png` | Character reference candidate | Singer | CANDIDATE | Arena.ai image generation | Original generated candidate | Cleaner adult singer reference, correct legs/boots, good whisk-as-microphone prop; possible lock candidate |
| CHAR002 | `generations/stills/candidates/CHAR_cowboy-reference_v001.png` | Character reference candidate | Cowboy | CANDIDATE | Arena.ai image generation | Original generated candidate | Strong cowboy cook direction; may need more waffle-specific props and fewer breakfast-skillet elements |
| LOC001 | `generations/stills/candidates/LOC_farmhouse-kitchen-wide_v001.png` | Location reference candidate | Kitchen | CANDIDATE | Arena.ai image generation | Original generated candidate | Strong farmhouse kitchen layout; good waffle iron, prep island, red gingham, warm light |
| S030 | `generations/stills/candidates/S030_good-morning-kiss-shirtless-cook_v001.png` | Story still candidate | Verse 1 / morning kitchen | CANDIDATE | Arena.ai image generation | Original generated candidate | Adult good-morning cheek-kiss while cowboy mixes batter shirtless under apron; tasteful but has tattoos and possible pseudo-text on bags |
